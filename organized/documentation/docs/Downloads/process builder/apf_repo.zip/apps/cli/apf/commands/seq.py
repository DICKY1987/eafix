import typer
from pathlib import Path

app = typer.Typer(no_args_is_help=True)

@app.command("insert")
def insert(input: Path = typer.Argument(..., exists=True, readable=True),
           after: str = typer.Option(..., "--after"),
           dry_run: bool = typer.Option(False, "--dry-run"),
           backup: bool = typer.Option(False, "--backup")):
    """
    Insert a step after the given StepKey (skeleton).
    """
    typer.echo(f"[stub] would insert after {after} in {input} (dry_run={dry_run}, backup={backup})")

@app.command("renumber")
def renumber(input: Path = typer.Argument(..., exists=True, readable=True),
             start: str = typer.Option("1.001", "--start"),
             increment: str = typer.Option("0.001", "--increment")):
    """
    Renumber steps to canonical precision (skeleton).
    """
    typer.echo(f"[stub] would renumber {input} starting at {start} with increment {increment}")