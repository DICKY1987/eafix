import typer
from pathlib import Path

app = typer.Typer(no_args_is_help=True)

@app.command()
def run(input: Path = typer.Argument(..., exists=True, readable=True, help="Input YAML spec"),
        format: str = typer.Option("md,drawio,json", "--format", "-f", help="Comma-separated formats"),
        output_dir: Path = typer.Option(Path("derived"), "--output-dir", "-o", help="Output directory"),
        verbose: bool = typer.Option(False, "--verbose", "-v")):
    """
    Export artifacts from a ProcessFlow YAML.
    This is a skeleton — wire to real exporters in import_export package.
    """
    formats = [x.strip() for x in format.split(",") if x.strip()]
    output_dir.mkdir(parents=True, exist_ok=True)
    for fmt in formats:
        out = output_dir / f"{input.stem}.{fmt}"
        out.write_text(f"[stub export] {fmt} for {input}\n", encoding="utf-8")
        if verbose:
            typer.echo(f"Wrote {out}")
    typer.echo("Export complete (stub).")