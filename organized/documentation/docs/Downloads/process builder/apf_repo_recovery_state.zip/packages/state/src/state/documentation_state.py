from __future__ import annotations

import json, time, hashlib, os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Optional, Tuple

from recovery.snapshot import Snapshotter, hash_bytes

def _now() -> int:
    return int(time.time())

def _vid(ts: int, content: bytes) -> str:
    return f"v{ts}-{hashlib.sha1(content).hexdigest()[:8]}"

@dataclass
class VersionInfo:
    version_id: str
    ts: int
    message: str = ""
    content_oid: str = ""
    size: int = 0

class DocumentState:
    """
    Linear version history with optional branch labels (future extension).
    Stores content-addressed blobs via Snapshotter and a manifest per document.
    """
    def __init__(self, doc_id: str, root: Path | str = ".apf_state"):
        self.doc_id = doc_id
        self.root = Path(root)
        self.doc_dir = self.root / "docs" / doc_id
        self.vers_dir = self.doc_dir / "versions"
        self.autosave_dir = self.root / "autosave"
        self.manifest_path = self.doc_dir / "manifest.json"
        self.snapshotter = Snapshotter()
        self._ensure()

    def _ensure(self):
        self.vers_dir.mkdir(parents=True, exist_ok=True)
        self.autosave_dir.mkdir(parents=True, exist_ok=True)
        if not self.manifest_path.exists():
            self._write_manifest({"doc_id": self.doc_id, "created_at": _now(), "versions": []})

    # --- manifest helpers ---
    def _read_manifest(self) -> Dict:
        return json.loads(self.manifest_path.read_text(encoding="utf-8"))

    def _write_manifest(self, data: Dict) -> None:
        self.doc_dir.mkdir(parents=True, exist_ok=True)
        self.manifest_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # --- API ---
    def list_versions(self) -> List[VersionInfo]:
        m = self._read_manifest()
        return [VersionInfo(**v) for v in m.get("versions", [])]

    def latest(self) -> Optional[VersionInfo]:
        vs = self.list_versions()
        return vs[-1] if vs else None

    def commit(self, content: str | bytes, message: str = "") -> VersionInfo:
        data = content.encode("utf-8") if isinstance(content, str) else content
        oid = self.snapshotter.snapshot_file(self._write_temp_blob(data))
        ts = _now()
        vid = _vid(ts, data)
        info = VersionInfo(version_id=vid, ts=ts, message=message, content_oid=oid, size=len(data))
        m = self._read_manifest()
        m.setdefault("versions", []).append(asdict(info))
        self._write_manifest(m)
        # Write a copy in versions folder for convenience
        (self.vers_dir / f"{vid}.blob").write_bytes(data)
        return info

    def checkout(self, version_id: Optional[str] = None) -> bytes:
        if version_id is None:
            v = self.latest()
            if not v: return b""
        else:
            v = next((x for x in self.list_versions() if x.version_id == version_id), None)
            if not v: return b""
        # Restore from object store
        tmp = self.vers_dir / f".restore-{version_id or 'latest'}.blob"
        self.snapshotter.restore_file(v.content_oid, tmp)
        data = tmp.read_bytes()
        tmp.unlink(missing_ok=True)
        return data

    def autosave(self, content: str | bytes) -> Path:
        data = content.encode("utf-8") if isinstance(content, str) else content
        p = self.autosave_dir / f"{self.doc_id}.autosave"
        p.write_bytes(data)
        return p

    # --- utilities ---
    def _write_temp_blob(self, data: bytes) -> Path:
        tmp = self.vers_dir / f".tmp-{_now()}.blob"
        tmp.write_bytes(data)
        return tmp
