"""
State
-----
Persistent document/process state, version graphs, and autosave for editors.
"""
from .documentation_state import DocumentState, VersionInfo

__all__ = ["DocumentState", "VersionInfo"]
