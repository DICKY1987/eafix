from __future__ import annotations
from pathlib import Path
from typing import Iterator, Tuple, List, Dict, Any

def stream_parse_file(path: Path | str, chunk_bytes: int = 8192) -> Iterator[Tuple[int, List[dict], List[dict]]]:
    """
    Incremental parser for large files.
    Yields (offset, diagnostics, partial_steps_list) for each chunk boundary.
    This stub tokenizes by lines and emits simplistic diagnostics for long lines.
    """
    p = Path(path)
    offset = 0
    buf = ""
    with p.open("r", encoding="utf-8") as f:
        while True:
            chunk = f.read(chunk_bytes)
            if not chunk:
                break
            buf += chunk
            lines = buf.splitlines(keepends=True)
            # Keep the last partial line in buffer
            if not buf.endswith(("\\n", "\n", "\r")):
                buf = lines[-1]
                lines = lines[:-1]
            else:
                buf = ""
            diags: List[dict] = []
            steps: List[dict] = []
            for ln in lines:
                if len(ln) > 2000:
                    diags.append({"severity": "WARN", "code": "APF0700", "message": "Very long line may degrade parsing"})
                # Extremely naive: treat bullet lines as steps
                if ln.lstrip().startswith(("- ", "* ", "+ ")):
                    steps.append({"text": ln.strip()})
            offset += sum(len(x) for x in lines)
            yield offset, diags, steps
    # final flush
    if buf:
        yield offset + len(buf), [], [{"text": buf.strip()}]
