from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from pathlib import Path
from typing import List, Dict, Any, Optional
import json, time, uuid


class Phase(Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    COMPLETED = "COMPLETED"


@dataclass
class RunState:
    run_id: str = field(default_factory=lambda: f"{int(time.time())}-{uuid.uuid4().hex[:8]}")
    phase: Phase = Phase.QUEUED
    input_file: str = ""
    output_dir: str = "derived"
    artifacts: List[str] = field(default_factory=list)
    diagnostics: List[Dict[str, Any]] = field(default_factory=list)
    attempts: int = 0
    started_at: float = 0.0
    updated_at: float = 0.0
    state_file: Optional[str] = None

    def start(self) -> None:
        self.phase = Phase.RUNNING
        now = time.time()
        self.started_at = self.started_at or now
        self.updated_at = now

    def complete(self) -> None:
        self.phase = Phase.COMPLETED
        self.updated_at = time.time()

    def fail(self, message: str, code: str = "APF0500") -> None:
        self.phase = Phase.FAILED
        self.updated_at = time.time()
        self.diagnostics.append({"severity": "ERROR", "code": code, "message": message, "run_id": self.run_id})

    def record_artifact(self, path: str) -> None:
        if path not in self.artifacts:
            self.artifacts.append(path)
        self.updated_at = time.time()

    def record_diagnostics(self, items: List[Dict[str, Any]]) -> None:
        if items:
            self.diagnostics.extend(items)
            self.updated_at = time.time()

    # Persistence
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["phase"] = self.phase.value
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RunState":
        rs = cls()
        for k, v in d.items():
            if k == "phase":
                rs.phase = Phase(v)
            else:
                setattr(rs, k, v)
        return rs

    def save(self, path: Optional[Path] = None) -> None:
        if path is None:
            if self.state_file:
                path = Path(self.state_file)
            else:
                out_dir = Path(".apf_runs")
                out_dir.mkdir(parents=True, exist_ok=True)
                path = out_dir / f"run_{self.run_id}.json"
                self.state_file = str(path)
        Path(self.state_file).write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "RunState":
        return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))