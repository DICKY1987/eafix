from __future__ import annotations
import json, sqlite3, time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from .migrations import migrate

class LibraryDB:
    def __init__(self, path: Path):
        self.path = path

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path))
        conn.row_factory = sqlite3.Row
        return conn

    def ensure_migrated(self) -> None:
        with self.connect() as conn:
            migrate(conn)

    # CRUD operations
    def insert_template(self, template_id: str, version: str, name: str, description: str, content: Dict[str, Any], tags: List[str]) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO templates (template_id, version, name, description, content_json, tags, created_at) VALUES (?,?,?,?,?,?,?)",
                (template_id, version, name, description, json.dumps(content, ensure_ascii=False), json.dumps(tags, ensure_ascii=False), int(time.time()))
            )
            rowid = cur.lastrowid
            # FTS mirror
            try:
                conn.execute("INSERT INTO templates_fts(rowid, template_id, name, description, tags, content_text) VALUES (?,?,?,?,?,?)",
                             (rowid, template_id, name, description, " ".join(tags), json.dumps(content, ensure_ascii=False)))
            except sqlite3.OperationalError:
                # FTS not available; ignore
                pass
            conn.commit()
            return rowid

    def get_template(self, template_id: str, version: Optional[str]) -> Optional[Dict[str, Any]]:
        with self.connect() as conn:
            if version is None:
                row = conn.execute(
                    "SELECT * FROM templates WHERE template_id=? ORDER BY created_at DESC LIMIT 1",
                    (template_id,)
                ).fetchone()
            else:
                row = conn.execute(
                    "SELECT * FROM templates WHERE template_id=? AND version=?",
                    (template_id, version)
                ).fetchone()
            if not row:
                return None
            return {
                "id": row["id"],
                "template_id": row["template_id"],
                "version": row["version"],
                "name": row["name"],
                "description": row["description"],
                "tags": json.loads(row["tags"] or "[]"),
                "content": json.loads(row["content_json"] or "{}"),
                "created_at": row["created_at"],
            }

    def search_templates(self, query: str, limit: int = 50) -> List[Dict[str, Any]]:
        with self.connect() as conn:
            rows = []
            if query.strip():
                try:
                    rows = conn.execute(
                        "SELECT t.* FROM templates_fts f JOIN templates t ON t.id=f.rowid WHERE templates_fts MATCH ? LIMIT ?",
                        (query, limit)
                    ).fetchall()
                except sqlite3.OperationalError:
                    # FTS unavailable, fallback to LIKE
                    q = f"%{query}%"
                    rows = conn.execute(
                        "SELECT * FROM templates WHERE template_id LIKE ? OR name LIKE ? OR description LIKE ? LIMIT ?",
                        (q, q, q, limit)
                    ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM templates ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
            out = []
            for r in rows:
                out.append({
                    "id": r["id"],
                    "template_id": r["template_id"],
                    "version": r["version"],
                    "name": r["name"],
                    "description": r["description"],
                    "tags": json.loads(r["tags"] or "[]"),
                    "content": json.loads(r["content_json"] or "{}"),
                    "created_at": r["created_at"],
                })
            return out
