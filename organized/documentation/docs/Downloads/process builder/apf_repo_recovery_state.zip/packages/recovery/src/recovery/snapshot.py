from __future__ import annotations

import hashlib, json, os, shutil, time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Iterable

def hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

@dataclass
class Snapshotter:
    store: Path = Path(".apf_store")

    def _obj_path(self, oid: str) -> Path:
        return self.store / "objects" / oid

    def _ensure(self) -> None:
        (self.store / "objects").mkdir(parents=True, exist_ok=True)
        (self.store / "manifests").mkdir(parents=True, exist_ok=True)

    # --- Blobs ---
    def snapshot_file(self, path: Path) -> str:
        """Store file content as a blob; returns object id (sha256)."""
        self._ensure()
        data = Path(path).read_bytes()
        oid = hash_bytes(data)
        obj = self._obj_path(oid)
        if not obj.exists():
            obj.write_bytes(data)
        return oid

    def restore_file(self, oid: str, target: Path) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(self._obj_path(oid), target)

    # --- Trees (directories) ---
    def snapshot_dir(self, path: Path, include_globs: Iterable[str] = ("**/*",)) -> str:
        """
        Snapshot a directory into a content-addressed manifest ("tree").
        Returns manifest id (sha256 of manifest JSON).
        """
        self._ensure()
        path = Path(path)
        entries: List[Dict] = []
        for pattern in include_globs:
            for p in path.glob(pattern):
                if p.is_file():
                    rel = str(p.relative_to(path))
                    blob = self.snapshot_file(p)
                    st = p.stat()
                    entries.append({
                        "path": rel,
                        "oid": blob,
                        "size": st.st_size,
                        "mtime": int(st.st_mtime),
                    })
        manifest = {"type": "tree", "root": str(path), "created_at": int(time.time()), "entries": sorted(entries, key=lambda e: e["path"])}
        mjson = json.dumps(manifest, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
        mid = hash_bytes(mjson)
        mpath = self.store / "manifests" / f"{mid}.json"
        if not mpath.exists():
            mpath.write_bytes(mjson)
        return mid

    def load_manifest(self, mid: str) -> Dict:
        return json.loads((self.store / "manifests" / f"{mid}.json").read_text(encoding="utf-8"))

    # --- Diff helpers ---
    def diff_manifests(self, a_mid: str, b_mid: str) -> Dict[str, List[Dict]]:
        """
        Return dict with 'added', 'removed', 'modified' lists based on path+oid comparison.
        """
        a = {e["path"]: e for e in self.load_manifest(a_mid).get("entries", [])}
        b = {e["path"]: e for e in self.load_manifest(b_mid).get("entries", [])}
        added = [{"path": k, **b[k]} for k in b.keys() - a.keys()]
        removed = [{"path": k, **a[k]} for k in a.keys() - b.keys()]
        modified = [{"path": k, "from": a[k]["oid"], "to": b[k]["oid"]} for k in a.keys() & b.keys() if a[k]["oid"] != b[k]["oid"]]
        return {"added": added, "removed": removed, "modified": modified}
