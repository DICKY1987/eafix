from __future__ import annotations

import shutil, tempfile, json, time, uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Dict, Any, Tuple, Optional
from .audit_log import AuditLogger

RollbackAction = Callable[[], None]

@dataclass
class Transaction:
    """
    Simple file-ops transaction with rollback.
    Usage:
        with Transaction().begin("update-config") as tx:
            tx.write_text(path, new_content)
            tx.move(src, dst)
    On error, all recorded actions are rolled back in reverse order.
    """
    name: str = "tx"
    run_id: Optional[str] = None
    logger: AuditLogger = field(default_factory=lambda: AuditLogger())
    _actions: List[RollbackAction] = field(default_factory=list, init=False)
    _active: bool = field(default=False, init=False)
    tx_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])

    # --- Context manager ---
    def begin(self, name: Optional[str] = None) -> "Transaction":
        if name:
            self.name = name
        self._active = True
        self.logger.write("tx.begin", {"tx_id": self.tx_id, "name": self.name, "run_id": self.run_id})
        return self

    def __enter__(self) -> "Transaction":
        return self.begin()

    def __exit__(self, exc_type, exc, tb):
        if exc is None:
            self.commit()
        else:
            self.rollback(reason=str(exc))
        return False  # re-raise exception after rollback

    # --- Operations ---
    def _record(self, action: RollbackAction) -> None:
        self._actions.append(action)

    def write_text(self, path: Path, content: str, encoding: str = "utf-8") -> None:
        path = Path(path)
        backup = None
        if path.exists():
            backup = path.with_suffix(path.suffix + f".txbak-{self.tx_id}")
            shutil.copy2(path, backup)
            self._record(lambda: shutil.move(str(backup), str(path)))
        else:
            self._record(lambda: path.unlink(missing_ok=True))

        tmp = Path(tempfile.mkstemp(prefix="apf-", suffix=".tmp")[1])
        tmp.write_text(content, encoding=encoding)
        shutil.move(str(tmp), str(path))
        self.logger.write("tx.write_text", {"tx_id": self.tx_id, "path": str(path)})

    def move(self, src: Path, dst: Path) -> None:
        src, dst = Path(src), Path(dst)
        if dst.exists():
            backup = dst.with_suffix(dst.suffix + f".txbak-{self.tx_id}")
            shutil.copy2(dst, backup)
            self._record(lambda: shutil.move(str(backup), str(dst)))
        else:
            self._record(lambda: dst.unlink(missing_ok=True))

        shutil.move(str(src), str(dst))
        self._record(lambda: shutil.move(str(dst), str(src)))
        self.logger.write("tx.move", {"tx_id": self.tx_id, "src": str(src), "dst": str(dst)})

    def delete(self, path: Path) -> None:
        path = Path(path)
        if path.exists():
            backup = path.with_suffix(path.suffix + f".txbak-{self.tx_id}")
            shutil.copy2(path, backup)
            self._record(lambda: shutil.move(str(backup), str(path)))
            path.unlink()
        else:
            self._record(lambda: None)
        self.logger.write("tx.delete", {"tx_id": self.tx_id, "path": str(path)})

    # --- Lifecycle ---
    def commit(self) -> None:
        self.logger.write("tx.commit", {"tx_id": self.tx_id, "name": self.name, "run_id": self.run_id})
        self._actions.clear()
        self._active = False

    def rollback(self, reason: str = "") -> None:
        for action in reversed(self._actions):
            try:
                action()
            except Exception:
                pass
        self.logger.write("tx.rollback", {"tx_id": self.tx_id, "name": self.name, "reason": reason, "run_id": self.run_id})
        self._actions.clear()
        self._active = False
