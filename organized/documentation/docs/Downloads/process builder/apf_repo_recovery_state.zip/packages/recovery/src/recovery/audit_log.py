from __future__ import annotations

import hashlib, json, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Any, Optional

def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

@dataclass
class AuditLogger:
    path: Path = Path(".apf_runs/audit.log")
    meta_path: Path = Path(".apf_runs/audit.meta.json")
    actor: str = "system"

    def _ensure(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.meta_path.exists():
            self.meta_path.write_text(json.dumps({"last_hash": ""}, indent=2), encoding="utf-8")

    def _last_hash(self) -> str:
        self._ensure()
        try:
            meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
            return meta.get("last_hash", "")
        except Exception:
            return ""

    def _update_last_hash(self, h: str) -> None:
        self.meta_path.write_text(json.dumps({"last_hash": h}, indent=2), encoding="utf-8")

    def write(self, action: str, details: Dict[str, Any]) -> str:
        """
        Append an entry with hash chaining: entry_hash = sha256(prev_hash + canonical_json).
        Returns the new entry_hash.
        """
        self._ensure()
        entry = {
            "ts": int(time.time()),
            "actor": self.actor,
            "action": action,
            "details": details,
        }
        canonical = json.dumps(entry, separators=(",", ":"), sort_keys=True)
        h = _sha256(self._last_hash() + canonical)
        line = json.dumps({"hash": h, **entry}, ensure_ascii=False)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        self._update_last_hash(h)
        return h

    def verify(self) -> bool:
        """
        Recompute the chain to ensure integrity.
        """
        prev = ""
        if not self.path.exists():
            return True
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                obj = json.loads(line)
                entry = {k: obj[k] for k in ("ts", "actor", "action", "details")}
                canon = json.dumps(entry, separators=(",", ":"), sort_keys=True)
                h = _sha256(prev + canon)
                if h != obj.get("hash"):
                    return False
                prev = h
        return True
