# APF Repo Skeleton

Generated from BU_* briefs: diagnostics schema, tests, CI, and app stubs.

## Plugins

First-party plugins live in `plugins/`:

- `atomic_process_engine/` — orchestrates import → validate → export
- `step_sequencer/` — insert and renumber commands
- `process_standardizer/` — normalize actors/actions using registries
- `diagram_generator/` — Draw.io exporter
- `validation_engine/` — deep validation surface
- `documentation/` — bundle docs into a ZIP

## New Packages

- `packages/process_library/` — SQLite-backed reusable step templates with FTS query and parameter substitution.
- `packages/apf_parser/` — Deterministic Markdown/structured-doc parsers and a streaming parser for large files.

## Orchestration

Added `packages/orchestration/` with:

- `state.py` — `RunState` lifecycle (QUEUED/RUNNING/FAILED/COMPLETED), persistence to `.apf_runs/run_<id>.json`
- `jobs.py` — base `Job`, `JobContext`, plus `ValidateJob` and `ExportJob` (md/json/yaml/drawio)
- `coordinator.py` — `Coordinator.run_export_pipeline()` plans `[Validate] -> Export*` fan-out/fan-in and records artifacts/diagnostics

## Recovery & State

- `packages/recovery/`
  - `snapshot.py` — content-addressed blob/tree snapshots, manifest diffs, restore
  - `transaction.py` — rollback-capable file operations with audit integration
  - `audit_log.py` — append-only JSONL with hash chaining + `verify()`
- `packages/state/`
  - `documentation_state.py` — linear version history, autosave, blob store integration

All paths and JSON structures are consistent with the existing repo style (`.apf_runs`, `.apf_store`, JSON diagnostics).