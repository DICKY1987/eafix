# APF Repo Skeleton

Generated from BU_* briefs: diagnostics schema, tests, CI, and app stubs.

## Plugins

First-party plugins live in `plugins/`:

- `atomic_process_engine/` — orchestrates import → validate → export
- `step_sequencer/` — insert and renumber commands
- `process_standardizer/` — normalize actors/actions using registries
- `diagram_generator/` — Draw.io exporter
- `validation_engine/` — deep validation surface
- `documentation/` — bundle docs into a ZIP