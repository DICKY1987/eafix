# APF Repo Skeleton

Generated from BU_* briefs: diagnostics schema, tests, CI, and app stubs.