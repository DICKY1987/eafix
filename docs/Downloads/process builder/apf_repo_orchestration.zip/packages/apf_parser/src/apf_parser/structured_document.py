from __future__ import annotations
import re
from typing import List, Dict, Any
from apf_core.models import ProcessFlow, Step
from apf_core.sequencing import StepSequencer

# Very deterministic Markdown mapping rules:
# - Headings (#, ##, ###) build context; not emitted as steps unless tagged as "[step]"
# - Bullet/numbered items become steps; if they include inline tags like [actor=exporter] [action=render] they are respected
# - Tables with columns Step ID|Actor|Action|Text|Next are parsed directly
# - Default actor/action fallbacks: actor=user, action=transform

TAG_RE = re.compile(r"\[(?P<k>actor|action|id|next)=(?P<v>[^\]]+)\]")
TABLE_HEADER_RE = re.compile(r"\|\s*Step ID\s*\|\s*Actor\s*\|\s*Action\s*\|\s*Text\s*\|\s*Next\s*\|", re.I)

def _parse_tags(line: str) -> dict:
    return {m.group("k"): m.group("v") for m in TAG_RE.finditer(line)}

def parse_markdown(md: str) -> ProcessFlow:
    lines = md.splitlines()
    steps: List[Step] = []
    context: List[str] = []
    sequencer = StepSequencer()
    pending_items: List[dict] = []

    # Detect table mode
    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1
            continue

        # Table parsing
        if TABLE_HEADER_RE.search(line):
            i += 1  # skip header separator row
            if i < len(lines) and set(lines[i].strip()) <= set("|-: "):
                i += 1
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = [c.strip() for c in lines[i].strip("|").split("|")]
                if len(row) >= 5:
                    sid, actor, action, text, nxt = row[:5]
                    next_ids = [x.strip() for x in nxt.split(",") if x.strip()]
                    steps.append(Step(id=sid or "", actor=actor or "user", action=action or "transform", text=text or "", next=next_ids))
                i += 1
            continue

        # Headings update context
        if line.startswith("#"):
            depth = len(line) - len(line.lstrip("#"))
            title = line[depth:].strip()
            context = context[:depth-1] + [title]
            i += 1
            continue

        # List items -> steps
        if line.lstrip().startswith(("- ", "* ", "+ ", "1. ", "2. ", "3. ")):
            content = line.lstrip()[2:].strip()
            tags = _parse_tags(content)
            actor = tags.get("actor", "user")
            action = tags.get("action", "transform")
            sid = tags.get("id")
            nxt = tags.get("next")
            text = re.sub(TAG_RE, "", content).strip()
            pending_items.append({"id": sid, "actor": actor, "action": action, "text": " / ".join(context + [text]), "next": [nxt] if nxt else []})
            i += 1
            continue

        i += 1

    # Assign ids deterministically
    ids = []
    for idx, item in enumerate(pending_items):
        if item["id"]:
            ids.append(item["id"])
        else:
            ids.append("0")  # placeholder
    # renumber placeholders
    assigned = []
    cur_id = "1.001"
    for idx, item in enumerate(pending_items):
        if item["id"] and item["id"] != "0":
            assigned.append(item["id"])
            cur_id = item["id"]
        else:
            assigned.append(cur_id if idx == 0 else str(idx))  # temporary
    # proper sequential ids using sequencer.renumber
    new_ids = StepSequencer().renumber(assigned, start="1.001", increment="0.001")
    id_map = {old: new for old, new in zip(assigned, new_ids)}

    for item, old in zip(pending_items, assigned):
        sid = id_map[old]
        steps.append(Step(id=sid, actor=item["actor"], action=item["action"], text=item["text"], next=item["next"]))

    meta = {"title": "Parsed Document"}
    return ProcessFlow(meta=meta, steps=steps)
