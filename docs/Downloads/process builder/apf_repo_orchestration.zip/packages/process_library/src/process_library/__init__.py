"""
Process Library
---------------
SQLite-backed storage of reusable step templates and snippet libraries.
Public surface:
- ProcessLibrary: open/initialize, CRUD templates, FTS query
- resolve_template_id: parse "id@version" strings
"""
from __future__ import annotations
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any
from .db import LibraryDB
from .templates import resolve_template_id, apply_params

class ProcessLibrary:
    def __init__(self, db_path: Path | str = "apf_library.sqlite"):
        self.db = LibraryDB(Path(db_path))

    def initialize(self) -> None:
        self.db.ensure_migrated()

    # Templates CRUD
    def add_template(self, template_id: str, version: str, name: str, description: str, content: Dict[str, Any], tags: list[str] | None = None) -> int:
        return self.db.insert_template(template_id, version, name, description, content, tags or [])

    def get_template(self, template_id: str, version: Optional[str] = None) -> Optional[Dict[str, Any]]:
        tid, ver = resolve_template_id(template_id, version)
        return self.db.get_template(tid, ver)

    def list_templates(self, query: str = "", limit: int = 50) -> List[Dict[str, Any]]:
        return self.db.search_templates(query, limit=limit)

    def apply_template(self, template_id: str, params: Dict[str, Any], version: Optional[str] = None) -> Dict[str, Any]:
        tpl = self.get_template(template_id, version)
        if not tpl:
            raise KeyError(f"Template not found: {template_id}@{version or 'latest'}")
        content = tpl["content"]
        # Recursively substitute placeholders in strings
        def _sub(obj):
            if isinstance(obj, str):
                return apply_params(obj, params)
            if isinstance(obj, list):
                return [_sub(x) for x in obj]
            if isinstance(obj, dict):
                return {k: _sub(v) for k, v in obj.items()}
            return obj
        applied = _sub(content)
        provenance = {"template_id": tpl["template_id"], "version": tpl["version"], "params": params}
        return {"provenance": provenance, "content": applied}
