from __future__ import annotations

from pathlib import Path
from typing import List
from .state import RunState
from .jobs import JobContext, ValidateJob, ExportJob

class Coordinator:
    """
    Plans an export pipeline:
      [optional Validate] -> fan-out [Export(fmt) ...] -> fan-in [collect]
    Sequential execution for determinism; models DAG phases internally.
    """

    def __init__(self, root: Path = Path(".")):
        self.root = root

    def run_export_pipeline(self, input_file: Path, formats: List[str], output_dir: Path = Path("derived"), validate: bool = True, state_file: Path | None = None) -> RunState:
        state = RunState(input_file=str(input_file), output_dir=str(output_dir))
        if state_file:
            state.state_file = str(state_file)
        state.start(); state.save()

        ctx = JobContext(root=self.root, input_file=input_file, output_dir=output_dir)

        try:
            if validate:
                vjob = ValidateJob()
                vres = vjob.execute(ctx)
                state.record_diagnostics(vres.get("diagnostics", []))
                state.save()

            for fmt in formats:
                ejob = ExportJob(fmt=fmt, name=f"export:{fmt}")
                eres = ejob.execute(ctx)
                art = eres.get("artifact")
                if art:
                    state.record_artifact(art)
                state.save()

            state.complete(); state.save()
            return state
        except Exception as e:
            state.fail(f"Coordinator failed: {e}")
            state.save()
            return state