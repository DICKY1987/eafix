from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable
from time import sleep

from import_export import load_yaml_flow
from import_export.exporters import export_markdown, export_json, export_yaml, export_drawio
from apf_core.validation import validate_flow

# Map format -> exporter function
EXPORTERS: Dict[str, Callable] = {
    "md": export_markdown,
    "json": export_json,
    "yaml": export_yaml,
    "drawio": export_drawio,
}

@dataclass
class JobContext:
    root: Path = Path(".")
    input_file: Path = Path("")
    output_dir: Path = Path("derived")


@dataclass
class Job:
    name: str
    max_retries: int = 2
    backoff_ms: int = 200

    def run(self, ctx: JobContext) -> Dict[str, Any]:
        raise NotImplementedError

    def execute(self, ctx: JobContext) -> Dict[str, Any]:
        attempts = 0
        last_err: Optional[Exception] = None
        while attempts <= self.max_retries:
            try:
                return self.run(ctx)
            except Exception as e:
                last_err = e
                attempts += 1
                if attempts > self.max_retries:
                    raise
                sleep(self.backoff_ms / 1000.0)
        # shouldn't reach
        raise last_err if last_err else RuntimeError("Unknown job failure")


@dataclass
class ValidateJob(Job):
    name: str = "validate"

    def run(self, ctx: JobContext) -> Dict[str, Any]:
        flow = load_yaml_flow(ctx.input_file)
        diags = validate_flow(flow, ctx.root)
        return {"diagnostics": diags}


@dataclass
class ExportJob(Job):
    fmt: str = "md"
    name: str = "export"

    def run(self, ctx: JobContext) -> Dict[str, Any]:
        if self.fmt not in EXPORTERS:
            raise ValueError(f"Unsupported format: {self.fmt}")
        flow = load_yaml_flow(ctx.input_file)
        content = EXPORTERS[self.fmt](flow)
        suffix = ".drawio" if self.fmt == "drawio" else f".{self.fmt}"
        ctx.output_dir.mkdir(parents=True, exist_ok=True)
        out = ctx.output_dir / f"{ctx.input_file.stem}{suffix}"
        out.write_text(content, encoding="utf-8")
        return {"artifact": str(out)}