"""
APF CLI package marker.
Exposes console entry points when installed.
"""
__all__ = []