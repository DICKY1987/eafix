from __future__ import annotations
import sqlite3

DDL = [
    # migrations table
    """CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL);""",
    # templates storage
    """CREATE TABLE IF NOT EXISTS templates(
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           template_id TEXT NOT NULL,
           version TEXT NOT NULL,
           name TEXT NOT NULL,
           description TEXT DEFAULT '',
           tags TEXT DEFAULT '[]',
           content_json TEXT NOT NULL,
           created_at INTEGER NOT NULL,
           UNIQUE(template_id, version)
       );""",
]

FTS = [
    # FTS mirror for quick search (if FTS5 available)
    """CREATE VIRTUAL TABLE IF NOT EXISTS templates_fts USING fts5(template_id, name, description, tags, content_text, content='');""",
]

SEED = [
    ("apf.retry_loop", "1.0.0", "Retry Loop", "Generic retry wrapper with max attempts and backoff.", 
     {"steps": [
         {"id": "1.001", "actor": "system", "action": "wait", "text": "Wait ${initial_delay_ms} ms"},
         {"id": "1.002", "actor": "system", "action": "validate", "text": "Check condition ${condition_name}"},
         {"id": "1.003", "actor": "system", "action": "decide", "text": "If not satisfied and attempts < ${max_attempts}, retry"}
     ]},
     ["retry","control","quality"]),
]

def migrate(conn: sqlite3.Connection) -> None:
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
    # Check current version
    cur.execute("SELECT MAX(version) FROM schema_migrations")
    row = cur.fetchone()
    current = row[0] or 0
    target = 1
    if current < 1:
        import time, json
        # Apply base DDL
        for stmt in DDL:
            cur.execute(stmt)
        # Try FTS
        try:
            for stmt in FTS:
                cur.execute(stmt)
        except sqlite3.OperationalError:
            pass
        # Seed
        for tid, ver, name, desc, content, tags in SEED:
            cur.execute("INSERT OR IGNORE INTO templates(template_id, version, name, description, content_json, tags, created_at) VALUES (?,?,?,?,?,?,?)",
                        (tid, ver, name, desc, json.dumps(content, ensure_ascii=False), json.dumps(tags, ensure_ascii=False), int(time.time())))
            try:
                cur.execute("INSERT INTO templates_fts(rowid, template_id, name, description, tags, content_text) SELECT id, template_id, name, description, tags, content_json FROM templates WHERE template_id=? AND version=?", (tid, ver))
            except sqlite3.OperationalError:
                pass
        cur.execute("INSERT INTO schema_migrations(version, applied_at) VALUES (?,?)", (1, int(time.time())))
        conn.commit()
