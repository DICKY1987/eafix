from __future__ import annotations
import re
from string import Template

ID_RE = re.compile(r"^(?P<id>[a-zA-Z0-9_.-]+)(?:@(?P<ver>[0-9][a-zA-Z0-9_.-]*))?$")

def resolve_template_id(template_id: str, version: str | None = None) -> tuple[str, str | None]:
    """
    Accept "id@version" or split id + version.
    Returns (id, version or None to indicate latest).
    """
    if version:
        return template_id, version
    m = ID_RE.match(template_id)
    if not m:
        raise ValueError(f"Invalid template id: {template_id!r}")
    return m.group("id"), m.group("ver")

def apply_params(text: str, params: dict) -> str:
    """
    Support ${var} and {{var}} placeholders. Uses safe_substitute.
    """
    if "{{" in text and "}}" in text:
        # Convert handlebars-style to ${}
        text = re.sub(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}", r"${\1}", text)
    return Template(text).safe_substitute(**params)
