"""
APF Parser
----------
Deterministic parsers that convert structured docs into ProcessFlow models.

Public API:
- parse_markdown(text) -> ProcessFlow
- parse_file(path) -> ProcessFlow
- stream_parse_file(path, chunk_bytes=8192) -> iterator of (offset, diagnostics, partial_steps)
"""
from __future__ import annotations
from pathlib import Path
from typing import Iterable, Tuple, List, Dict, Any
from apf_core.models import ProcessFlow, Step
from apf_core.sequencing import StepSequencer
from .structured_document import parse_markdown
from .streaming import stream_parse_file

def parse_file(path: Path | str) -> ProcessFlow:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    return parse_markdown(text)

__all__ = ["parse_markdown", "parse_file", "stream_parse_file"]
